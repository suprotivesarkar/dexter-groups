           <div class="col-md-3">
                	<div class="box_style_2">
                        <h5>Address</h5>
                            <ul>
                                <li><strong>Registered Office</strong>
                                    <br>1D, Motijheel Lane,<br>Kolkata - 700 015<br> West Bengal. India
                                </li>
                                <li><strong>Liaison Office</strong>
                                    <br>51 K /2A Pottery Road, Kolkata - 700 015<br> West Bengal. India
                                </li>
                                
                            </ul>
                             <h5>Contacts</h5>
                            <ul>
                            	 <li><strong>Contact Person</strong><br>Mr. Kajal Sinha ( Managing Director )</li>
                                <li><strong>Phone</strong><br><a href="tel:+91 98303 84234">+91 98303 84234</a><br><small>Mon to Sat 9am - 9pm</small></li>
                                <li><strong>General info</strong><br><a href="mailto:admin@dextergroup.in">admin@dextergroup.in</a>
                                <br><a href="mailto:dextergroup1965@gmail.com">dextergroup1965@gmail.com</a></li>
                                <li><strong>Request a callback</strong><p class="nopadding">Leave us a mail at <br><a href="mailto:admin@dextergroup.in">admin@dextergroup.in</a> and our team will contact you within a day.</p></li>
                            </ul>
                    </div>
                    <div class="quote_banner"><i class="fa fa-calculator"></i><a href="quotation">Need a quotation ?</a></div>
                </div>