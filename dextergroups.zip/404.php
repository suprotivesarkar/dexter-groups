<?php 
include '_top.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="HOMEALARMS - Alarms and security systems site template">
	<meta name="author" content="Ansonika">
	<title>DEXTER GROUPS - 404</title>
	<?php include '_header.php'; ?>
	<style type="text/css">
.errorimg{max-height:400px;
	width:auto;
text-align: center;}
</style>
</head>
<body>	
<main>
	<div class="container margin_60_35">
		<div class="row">
		<center><a href="./"><img src="img/404.png" class="errorimg"></a></center>
		</div>
	</div>
</main>
</body>
</html>

