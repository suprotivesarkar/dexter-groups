Introduction
This module extends the default functionality of Owl Carousel to integrate Colorbox. Please follow the Colorbox installation instructions via the Colorbox module page. Onced installed; Colorbox support is provided on a per settings basis and supports all display methods if run through the Owl Carousel theme functions, this includes Views, Field formatter etc.

Credits
This extension was made possible by rcodina. Please see https://www.drupal.org/node/2307421 to view all contributors.
