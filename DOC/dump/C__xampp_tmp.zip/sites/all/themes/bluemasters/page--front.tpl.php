<div id="page">

    <!--header-top-->
   
    <!--EOF:header-top-->
    
    <div id="wrapper">
    	
        <!--header-->
        <div id="header" class="clearfix container_12">
        	
            <div class="grid_5">
                <!--logo-floater-->
                <div id="logo-floater"> 
        			<?php if ($logo): ?>
                    <a href="<?php print check_url($front_page); ?>" title="<?php print t('Home'); ?>">
                    <img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
                    </a>
                    <?php endif; ?>
                    
                    <?php if ($site_name || $site_slogan): ?>
                    <div class="clearfix">
        				<?php if ($site_name): ?>
                        <span id="site-name"><a href="<?php print check_url($front_page); ?>" title="<?php print t('Home'); ?>"><?php print $site_name; ?></a></span>
						<?php endif; ?>
                        
                        <?php if ($site_slogan): ?>
                        <span id="slogan"><?php print $site_slogan; ?></span>
						<br />
						<span id="slogan">Dexter Fire industries</span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div> 
                <!--EOF:logo-floater-->
            </div>

            <div class="grid_7">
                <!--ISO Certificate-->
				<?php
					global $base_url;
					
				?>
					<!-- <div class="iso_certificate">
						<a href="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert1.jpg" target="_blank">
							<img src="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert1.jpg" alt="ISO Certificate" />
						</a>
						
						<a href="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert2.jpg" target="_blank">
							<img src="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert2.jpg" alt="ISO Certificate" />
						</a>
						
						<a href="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert3.jpg" target="_blank">
							<img src="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert3.jpg" alt="ISO Certificate" />
						</a>
						
						<a href="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert4.jpg" target="_blank">
							<img src="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert4.jpg" alt="ISO Certificate" />
						</a>
						<div>
							<span>An ISO 9001:2008' Certified Co.</span>
						</div>
					</div> -->
                <!--EOF:ISO certificate-->
				
				<div id="navigation">
					<?php if ($page['navigation']) :?>
					<?php print drupal_render($page['navigation']); ?>
					<?php else :
					if (module_exists('i18n_menu')) {
					$main_menu_tree = i18n_menu_translated_tree(variable_get('menu_main_links_source', 'main-menu'));
					} else { $main_menu_tree = menu_tree(variable_get('menu_main_links_source', 'main-menu')); }
					print drupal_render($main_menu_tree);
					endif; ?>
				</div>
				
            </div>
           
        </div>
        <!--EOF:header-->

        <div class="container_12">
            
            <div class="grid_12">
                <!--banner-->
                <div id="banner">
                <?php print render($page['banner']); ?>
                
                <?php if (theme_get_setting('slideshow_display','bluemasters')): ?>

                <!--#slideshow-->
                <div id="slideshow">
                
                <div class="flexslider">
                <ul class="slides">
                
                <!-- slider-item -->
                <li class="slider-item">
                <div class="slider-item-image">
                <a href="<?php print url('node/1'); ?>"><img src="<?php print base_path() . drupal_get_path('theme', 'bluemasters') . '/images/company.jpg'; ?>"></a>
                </div>
                <div class="slider-item-caption">Company Profile</div>
                </li>
                <!-- EOF: slider-item -->
                
                <!-- slider-item -->
                <li class="slider-item">
                <div class="slider-item-image">
                <a href="<?php print url('node/2'); ?>"><img src="<?php print base_path() . drupal_get_path('theme', 'bluemasters') . '/images/customers.png'; ?>"></a>
                </div>
                <div class="slider-item-caption">Esteemed Clients</div>
                </li>
                <!-- EOF: slider-item -->
                
                <!-- slider-item -->
                <li class="slider-item">
                <div class="slider-item-image">
                <a href="<?php print url('node/3'); ?>"><img src="<?php print base_path() . drupal_get_path('theme', 'bluemasters') . '/images/services.jpg'; ?>"></a>
                </div>
                <div class="slider-item-caption">Our Services</div>
                </li>
                <!-- EOF: slider-item -->
                
                </ul>
                </div>
                
                </div>
                <!--EOF:#slideshow-->

                <?php endif; ?>

                </div>
                <!--EOF:banner-->
            </div>    

        </div>

        <div class="container_12">
          
            <div class="grid_12">
                <!--home-block-area-->
                <div id="home-blocks-area" class="clearfix">
                
            		<?php if ($messages): ?>
                    <div class="clearfix">
                    <?php print $messages; ?>
                    </div>
                    <?php endif; ?>

                    <div class="grid_4 alpha">
                        <div class="column-fix">
                            <div class="home-block-area first">
                                <?php print render($page['home_area_1']);?> 		
                            </div>
                        </div>
                    </div>

                    <div class="grid_4 alpha omega">
                        <div class="column-fix">
                            <div class="home-block-area">
                                <?php print render($page['home_area_2']);?> 
                            </div>
                        </div>
                    </div>

                    <div class="grid_4 omega">
                        <div class="column-fix">
                            <div class="home-block-area last">
                                <?php print render($page['home_area_3']);?> 
                                <?php //print render($page['home_area_3_b']);?> 
                            </div>
                        </div>
                    </div>

                </div>
                <!--EOF:home-block-area-->
            </div>    

        </div>
		
		
		
		
		<div class="container_12">
          
            <div class="grid_13">
                <!--ISO Certificate-->
				<?php
					global $base_url;
					
				?>
					<div class="iso_certificate">
						<div class="iso-title"><i>An ISO 9001:2008' Certified Co.</i></div>
						<div class="iso-inner">
							<a href="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert1.jpg" target="_blank">
								<img src="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert1.jpg" alt="ISO Certificate" />
							</a>
							
							<a href="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert2.jpg" target="_blank">
								<img src="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert2.jpg" alt="ISO Certificate" />
							</a>
							
							<a href="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert3.jpg" target="_blank">
								<img src="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert3.jpg" alt="ISO Certificate" />
							</a>
							
							<a href="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert4.jpg" target="_blank">
								<img src="<?php echo $base_url; ?>/sites/all/themes/bluemasters/images/107883cert4.jpg" alt="ISO Certificate" />
							</a>
						</div>
					</div>
                <!--EOF:ISO certificate-->
			</div>

        </div>
		

    </div>
    <!--EOF:wrapper-->



    <!--footer-bottom-->
    <div id="footer-bottom">

        <div class="container_12">

            <div class="grid_12">
                <div class="credits-container clearfix">
                    <a title="Dexter Group" class="dexter_bottom" href="http://www.dexter.in">
						<img src="http://www.dextergroup.in/sites/default/files/dexter-footer.png" alt="Home">
					</a>
				</div>
				<div class="address-block">
					<?php if ($page['footer_bottom']) :?>
					<?php print render($page['footer_bottom']); ?>
					<?php endif; ?>
				</div>
				<div class="phone-block">
					<?php if ($page['footer_right']) :?>
					<?php print render($page['footer_right']); ?>
					<?php endif; ?>
				</div>

			</div>  

		</div>
	</div>
    <!--EOF:footer-bottom-->

</div>
<!--EOF:page-->